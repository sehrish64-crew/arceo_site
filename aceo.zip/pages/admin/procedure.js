'use client';

import Proceduring from '@/components/Procedure';

export default function Inventory() {
  return (
    <div>
      <Proceduring />
    </div>
  );
}
