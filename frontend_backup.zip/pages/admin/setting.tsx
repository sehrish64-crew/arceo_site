'use client';

import SetPaage from '@/components/Setting';

export default function DoctorsPage() {
  return (
    <div>
      <SetPaage />
    </div>
  );
}
