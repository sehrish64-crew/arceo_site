'use client';

import Calendarsheet from '../../components/Calendar';

export default function Calendar() {
  return (
    <div>
      <Calendarsheet />
    </div>
  );
}
