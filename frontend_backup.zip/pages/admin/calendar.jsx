'use client';

import Calendarsheet from '../../components//Calendar';

export default function Inventory() {
  return (
    <div>
      <Calendarsheet />
    </div>
  );
}
